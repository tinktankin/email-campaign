from django.apps import AppConfig


class ComposeConfig(AppConfig):
    name = 'compose'
