﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","en-gb",{title:"UI Colour Picker",preview:"Live preview",config:"Paste this string into your config.js file",predefined:"Predefined colour sets"});